"""Pricing and execution adapters."""

