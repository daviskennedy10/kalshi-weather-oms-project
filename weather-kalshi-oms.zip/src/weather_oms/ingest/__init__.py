"""External data adapters."""

